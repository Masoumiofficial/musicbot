<?php
set_time_limit(0);
$link1080 = $_POST['hs_video1080p'];
$link720 = $_POST['hs_video720p'];
$link480 = $_POST['hs_video480p'];
$video_file = $_POST['video_file'];
$dir_file = $_POST['dir_file'];
if ( ! file_exists($dir_file))
    mkdir($dir_file, 0755, true);

$GenerateTrackLink1080 = $_SERVER['DOCUMENT_ROOT'] . "/$dir_file/{$video_file} (1080p).mp4";
$GenerateTrackLink720 = $_SERVER['DOCUMENT_ROOT'] . "/$dir_file/{$video_file} (720p).mp4";
$GenerateTrackLink480 = $_SERVER['DOCUMENT_ROOT'] . "/$dir_file/{$video_file} (480p).mp4";

function Download($url, $saveto){
	$content = file_get_contents($url);
	file_put_contents($saveto, $content);
}

if (!empty($link1080)) Download($link1080, $GenerateTrackLink1080);
if (!empty($link720)) Download($link720, $GenerateTrackLink720);
if (!empty($link480)) Download($link480, $GenerateTrackLink480);

?>
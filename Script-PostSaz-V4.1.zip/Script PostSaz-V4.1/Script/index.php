<?php
include $_SERVER['DOCUMENT_ROOT'].'/wp-config.php';

$username = "admin";
$password = "0000";
$nonsense = "supercalifragilisticexpialidocious";
if (isset($_COOKIE['PrivatePageLogin'])) {
if ($_COOKIE['PrivatePageLogin'] == md5($password.$nonsense)) {
?>
<!DOCTYPE html>
<html dir="rtl" lang="fa-IR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>پست سریع موزیک وین تم</title>
<META NAME="robots" CONTENT="noindex, nofollow">
<link href="style.css" rel="stylesheet" type="text/css">
<script src="js/jquery.js"></script>

</head>
<body>
<div class="newtab">
<!-- The navigation menu -->
<div class="navbar">
  <a href="#home">صفحه اصلی سایت</a>
  <div class="subnav">
    <button class="subnavbtn">دسته ها <i class="cat-icon"></i></button>
    <div class="subnav-content">
	<?php include ('menu.php'); ?>
    </div>
  </div>
  <a href="https://wintheme.ir">پشتیبانی</a>
</div> 
</div>
<center>
<div class="entry">
<div class="cadr">
<form enctype='multipart/form-data' method="POST" action="includes/music.php">
<script>  
jQuery(document).ready(function($) {
    $("input[type=file]").change(function () {
        $(this).parents(".uploader").find(".filename").val($(this).val());
    });
    $("input[type=file]").each(function () {
        if ($(this).val() == "") {
            $(this).parents(".uploader").find(".filename").val("هنوز فایلی انتخاب نشده...");
        }
    });
    });
</script>
<div class="title">
<label>نوع پست</label>
<select name="musictype" id="musictype">
<option value="music">آهنگ</option>
<option value="remix">ریمیکس</option>
<option value="nohe">مداحی</option>
<option value="pod">پادکست</option>
</select>

<label>وضعیت پست</label>
<select name="is_draft" id="is_draft">
<option value="publish">منتشر شود</option>
<option value="draft">پیشنویس شود</option>
</select>
</div>
<input type="text" name="artist" placeholder="نام خواننده" style="text-align:right;padding: 5px;" required>
<input type="text" name="track" placeholder="نام آهنگ" style="text-align:right;padding: 5px;">
<input type="text" name="artist_en" placeholder="نام خواننده - انگلیسی" style="direction: ltr;text-align:left;padding: 5px;" required>
<input type="text" name="track_en" placeholder="نام آهنگ - انگلیسی" style="direction: ltr;text-align:left;padding: 5px;">
<input type="text" name="info" placeholder="اطلاعات پست" style="width: 98%;text-align:right;padding: 5px;">
<textarea name="lyric" placeholder="متن آهنگ" style="width: 98%; resize: vertical;height: 8em;text-align: center;padding: 1em;"></textarea>
<input type="text" name="covermp3" placeholder="لینک کاور فایل MP3" style="width: 98%;text-align:right;padding: 5px;">
<div class="uploader" style="width: 36%;">
<input name="filemusic128" type="file">
<input name="file" class="button" value="فایل موزیک 128" type="button">
<input class="filename" readonly="readonly" type="text">
</div>
<input type="text" name="music128" placeholder="لینک موزیک 128" style="width: 60%;text-align:right;padding: 5px;border: 1px solid #b3000c;border-radius: 1em;">

<div class="uploader" style="width: 36%;">
<input name="filemusic320" type="file">
<input name="file" class="button" value="فایل موزیک 320" type="button">
<input class="filename" readonly="readonly" type="text">
</div>
<input type="text" name="music320" placeholder="لینک موزیک 320" style="width: 60%;text-align:right;padding: 5px;border: 1px solid #b3000c;border-radius: 1em;">

<div class="uploader" style="width: 36%;">
<input name="mp3_image" type="file">
<input name="file" class="button" value="فایل تصویر شاخص" type="button">
<input class="filename" readonly="readonly" type="text">
</div>
<input type="text" name="cover" placeholder="لینک کاور پست" style="width: 60%;text-align:right;padding: 5px;border: 1px solid #b3000c;border-radius: 1em;">
<br>
<input type="submit" name="button" id="button" class="backk" value="ارسال پست">
</form>
</div>
</div>
</center>
</body>
</html>
<?php
exit;
} else {
echo "<div style=\"width: 350px; margin: 16% auto;\"><div style=\"border-bottom: 1px dotted rgb(136, 136, 136); text-align: center; font: bold 12px tahoma; padding: 5px 0px;\">ERROR 401</div><div style=\"color: rgb(102, 102, 102); text-align: center; font: 11px tahoma; padding: 5px;\">Bad Cookie.</div></div>";
exit;
}
}
if (isset($_GET['p']) && $_GET['p'] == "login") {
if ($_POST['user'] != $username) {
echo "<div style=\"width: 350px; margin: 16% auto;\"><div style=\"border-bottom: 1px dotted rgb(136, 136, 136); text-align: center; font: bold 12px tahoma; padding: 5px 0px;\">ERROR 401</div><div style=\"color: rgb(102, 102, 102); text-align: center; font: 11px tahoma; padding: 5px;\">Sorry, that username does not match.</div></div>";
exit;
} else if ($_POST['keypass'] != $password) {
echo "<div style=\"width: 350px; margin: 16% auto;\"><div style=\"border-bottom: 1px dotted rgb(136, 136, 136); text-align: center; font: bold 12px tahoma; padding: 5px 0px;\">ERROR 401</div><div style=\"color: rgb(102, 102, 102); text-align: center; font: 11px tahoma; padding: 5px;\">Sorry, that password does not match.</div></div>";
exit;
} else if ($_POST['user'] == $username && $_POST['keypass'] == $password) {
setcookie('PrivatePageLogin', md5($_POST['keypass'].$nonsense));
header("Location: $_SERVER[PHP_SELF]");
} else {
echo "<div style=\"width: 350px; margin: 16% auto;\"><div style=\"border-bottom: 1px dotted rgb(136, 136, 136); text-align: center; font: bold 12px tahoma; padding: 5px 0px;\">ERROR 401</div><div style=\"color: rgb(102, 102, 102); text-align: center; font: 11px tahoma; padding: 5px;\">Sorry, you could not be logged in at this time.</div></div>";
}
}
?>
<html>
<head>
<meta content="no-cache" http-equiv="pragma">
<title>ورود به پنل ارسال پست</title>
<style>
@font-face{font-family:irsans;font-style:normal;font-weight:400;src:url(fonts/irsans.woff) format("woff"),url(fonts/irsans.woff2) format("woff2");font-display:swap}
*{border:0;padding:0;margin:0;box-sizing:border-box}
a{text-decoration:none}
html,body,div,span,h1,h2,h3,h4,h5,h6,p,a,img,ol,ul,li,input,button{padding:0;margin:0;transition:all .3s ease-out}
body{direction:rtl;color:#2C2E3E;margin:0;padding:0;text-align:center;font:12px irsans;overflow-x:hidden;background:#2C2E3E;cursor:default}
label{float:right;margin:5px 0;padding:11px 5px 5px}
input {font: 14px irsans;padding: 10px 15px;margin: 5px;float: left;width: 70%;text-align: left;direction: ltr;color: #1f1f1f;border: 2px solid #D9DCEE;border-radius: 0.5em;}
input:hover,input:focus{border-color:#2C2E3E}
button{margin:1.5em 0 1em;color:#fff;font:15px irsans;background:#EE2B47;cursor:pointer;padding:1em 2em;border-radius:1em}
button:hover{background:#2C2E3E;color:#fff}
div.box{margin:0 auto;width:70%;background:#fff;padding:15px;border-radius:10px;box-shadow:0 0 5px #000;position:absolute;width:460px;top:40%;left:50%;margin-left:-230px;margin-top:-100px}
.list{width:90%;display:inline-block}
.title{width:100%;margin-bottom:10px;float:right;padding:15px}
.title span{padding:5px 15px;font-size:16px;background:#393C53;color:#fff;border-radius:1em}
.footer{margin:10px 0 0;width:100%;background:RGBA(59,37,54,0.2);padding:9px 0;color:#3B2536;border-radius:5px}
.footer a{color:#3B2536}
</style>
</head>
<div class="box">
<div class="title"><span>ورود به پنل ارسال پست</span></div>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>?p=login" method="post">
<div class="list">
<label>نام کاربری</label>
<input type="text" name="user" id="user" placeholder="admin">
</div>
<div class="list">
<label>رمز عبور</label>
<input type="password" name="keypass" id="keypass" placeholder="*****">
</div>
<div class="list"><button type="submit" id="submit" class="button" value="Login">ورود</button></div>
</form>
<div class="footer">برنامه نویسی شده توسط : <a title="وین تم" target="_blank" href="http://wintheme.ir">وین تم</a></div>
</div>
</body>
</html>
<?php
//******************************************
// @ This Script created by Saeid Moradi
// @ Email: saeid.m2126@gmail.com
// @ URL  : https://wintheme.ir
//******************************************
	define('IMG_WIDTH',  480);
	define('IMG_HEIGHT', 480);
	require_once 'jdf.php';
	include("../config.php");
	include $_SERVER['DOCUMENT_ROOT'].'/wp-config.php';
	set_time_limit(0);
	$dir = jdate_win('Y/m/d', time());
	$dir_files = "album/{$dir}";
	$artist = $_POST['artist'];
	$song = $_POST['track'];
	$artist_en = $_POST['artist_en'];
	$song_en = $_POST['track_en'];
	$info = $_POST['info'];
	$cover = $_POST['cover'];
	$is_draft = $_POST['is_draft'];
	$covermp3 = $_POST['covermp3'];
	$src = trim($cover);
	
	for($i=1;$i<=30;$i++) {
		if(!empty($_POST['trackfa_'.$i.'_name'])) {
			$hs_tracknamefa_{$i} = $_POST['trackfa_'.$i.'_name'];
		}
		if(!empty($_POST['tracken_'.$i.'_name'])) {
			$hs_trackname_{$i} = $_POST['tracken_'.$i.'_name'];
		}
		if(!empty($_POST['track_'.$i.'_128'])) {
			$hs_link_128_{$i} = $_POST['track_'.$i.'_128'];
		}
		if(!empty($_POST['track_'.$i.'_320'])) {
			$hs_link_320_{$i} = $_POST['track_'.$i.'_320'];
		}
	}

	$year = date("Y");
	$months = date("m");

	$title = "دانلود آلبوم {$artist} {$song}";
	$title_seo = "دانلود آلبوم {$artist} {$song} | با کیفیت عالی";
	$Post_Name = "{$artist} {$song}";
	$cover_file = "{$artist_en} - {$song_en}";
	$mp3_file = "{$artist_en} - {$song_en}";
	$mp3_file_128 = "{$artist_en} - {$song_en} [128]";

	$post_url = "آلبوم {$artist} {$song}";
	$IMG_POST = "https://{$urlsite}/wp-content/uploads/{$year}/{$months}/{$cover_file}.jpg";
	$tag_cat_my_content = "https://{$urlsite}/tag/دانلود-آلبوم-جدید/";

	$art_dashes = sanitize_title_with_dashes($artist);$song_dashes = sanitize_title_with_dashes($song);$art_en_dashes = sanitize_title_with_dashes($artist_en);$song_en_dashes = sanitize_title_with_dashes($song_en);
	$Artist_Name_FA_TAG = "https://{$urlsite}/tag/{$art_dashes}/";
	$Song_Name_FA_TAG = "https://{$urlsite}/tag/{$song_dashes}/";
	$Artist_Name_EN_TAG = "https://{$urlsite}/tag/{$art_en_dashes}/";
	$Song_Name_EN_TAG = "https://{$urlsite}/tag/{$song_en_dashes}/";

	$metadesc_text_fa = "دانلود آلبوم {$artist} {$song} دانلود آلبوم جدید {$song} از {$artist} - Download New Album {$artist_en} {$song_en} متن ترانه";

$my_post_content = "
<h2 style=\"text-align: center;\"><span style=\"color: #808080;\">آلبوم {$artist} {$song}</span></h2>
<p style=\"text-align: center;\"><strong><span style=\"color: #999999;\"><a href=\"https://mahyarmusic.com/category/album/\">دانلود آلبوم جدید</a>  <a href=\"{$Artist_Name_FA_TAG}\">{$artist}</a> به نام <a href=\"{$Song_Name_FA_TAG}\">{$song}</a> با دو کیفیت عالی </span></strong></p>
<p style=\"text-align: center;\"><strong>{$artist_en} - {$song_en}</strong></p>
<p style=\"text-align: center;\">{$info}</p>
<p style=\"text-align: center;\"><img src=\"{$IMG_POST}\" alt=\"{$title}\" width=\"480\" height=\"480\" /></p>
<!--more-->
";

	if($is_draft == "publish") {
		$type="publish";	
	}
	if($is_draft == "draft") {
		$type="draft";
	}
	$post_id = wp_insert_post( array(
		 'post_author' => '1',
		 'post_status' => $type,
		 'post_type' => 'post',
		 'post_title' => $title,
		 'post_name' => sanitize_title_with_dashes($post_url),
		 'post_content' => $my_post_content,
	 ) );

	update_post_meta($post_id, '_yoast_wpseo_title', strip_tags($title));
	update_post_meta($post_id, '_yoast_wpseo_metadesc', strip_tags($metadesc_text_fa));
	update_post_meta($post_id, '_yoast_wpseo_focuskw', strip_tags($post_url));
	update_post_meta($post_id, '_yoast_wpseo_linkdex', '99');
	update_post_meta($post_id, '_yoast_wpseo_content_score', '99');
 
	$arrayoftags = array(
		"دانلود آلبوم جدید",
		"دانلود آلبوم",
		"دانلود آلبوم $song",
		"دانلود آلبوم $artist",
		"$song_en",
		"$song",
		"$artist_en",
		"$artist"
	);

	for($i=1;$i<=30;$i++) {
		if(!empty($_POST['tracken_'.$i.'_name'])) {
			if ( $i<=9 ) {
				$num = "0".$i;
				$hs_tracknamefile_{$i} = "{$num}. {$artist_en} - {$hs_trackname_{$i}}";
			} else {
				$hs_tracknamefile_{$i} = "{$i}. {$artist_en} - {$hs_trackname_{$i}}";
			}
		}	
	}
	
	for($i=1;$i<=30;$i++) {
		$mp3320_{$i} = "{$urldlhost}/{$dir_files}/{$mp3_file}/{$hs_tracknamefile_{$i}}.mp3";
		$mp3128_{$i} = "{$urldlhost}/{$dir_files}/{$mp3_file_128}/{$hs_tracknamefile_{$i}} [128].mp3";
	}	

	for($i=1;$i<=30;$i++) {
		if(!empty($_POST['trackfa_'.$i.'_name'])) {
			update_post_meta($post_id, 'track_name_'.$i.'',$_POST['trackfa_'.$i.'_name'] );
		}
		if(!empty($_POST['track_'.$i.'_128'])) {
			update_post_meta($post_id, 'mp3128_'.$i.'', $mp3128_{$i});
		}
		if(!empty($_POST['track_'.$i.'_320'])) {
			update_post_meta($post_id, 'mp3320_'.$i.'', $mp3320_{$i});
		}
	}
	
	$zip320 = "{$urldlhost}/{$dir_files}/{$mp3_file}.zip";
	$f320 = "{$urldlhost}/{$dir_files}/{$mp3_file}";
	$zip128 = "{$urldlhost}/{$dir_files}/{$mp3_file_128}.zip";
	$f128 = "{$urldlhost}/{$dir_files}/{$mp3_file_128}";
	
	update_post_meta($post_id, 'posttype', 'آلبوم');
	wp_set_object_terms($post_id, $arrayoftags, 'post_tag');
	wp_set_object_terms($post_id, 'album', 'category');

    wp_set_object_terms($post_id, $artist, 'singer');

	if(!empty($_POST['track_1_320'])) {
		if (!empty($zip320)) update_post_meta($post_id, 'album320', $zip320);
		if (!empty($f320)) update_post_meta($post_id, 'album_folder_320', $f320);
	}
	if(!empty($_POST['track_1_128'])) {
		if (!empty($zip128)) update_post_meta($post_id, 'album128', $zip128);
		if (!empty($f128)) update_post_meta($post_id, 'album_folder_128', $f128);
	}
	if (!empty($artist)) update_post_meta($post_id, 'artist', $artist);
	if (!empty($song)) update_post_meta($post_id, 'song', $song);
	
	
		function Download($url, $saveto) {
		$content = file_get_contents($url);
		file_put_contents($saveto, $content);
			} 

	
	
	if(isset($_FILES['mp3_image'])){
		$target = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/{$year}/{$months}/{$cover_file}.jpg";
		if(move_uploaded_file($_FILES['mp3_image']['tmp_name'],$target));
	}elseif ($_POST['cover']) {
		Download($src,$_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/{$year}/{$months}/{$cover_file}.jpg");
		} 
	
	$filename = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/{$year}/{$months}/{$cover_file}.jpg";
	if ($_POST['covermp3']) {
			$covermp3s_tr = trim($covermp3);
			$cover_file_mp3 = str_replace(" ", "%20", $covermp3s_tr);
		} else { 
			$covermp3s_tr = trim($IMG_POST);
			$cover_file_mp3 = str_replace(" ", "%20", $covermp3s_tr);
		}
	
	$ch = curl_init($wintheme_url_function_album);
	$wintheme = array(
	'hs_link_128_1' => $hs_link_128_[1],
	'hs_link_128_2' => $hs_link_128_[2],
	'hs_link_128_3' => $hs_link_128_[3],
	'hs_link_128_4' => $hs_link_128_[4],
	'hs_link_128_5' => $hs_link_128_[5],
	'hs_link_128_6' => $hs_link_128_[6],
	'hs_link_128_7' => $hs_link_128_[7],
	'hs_link_128_8' => $hs_link_128_[8],
	'hs_link_128_9' => $hs_link_128_[9],
	'hs_link_128_10' => $hs_link_128_[10],
	'hs_link_128_11' => $hs_link_128_[11],
	'hs_link_128_12' => $hs_link_128_[12],
	'hs_link_128_13' => $hs_link_128_[13],
	'hs_link_128_14' => $hs_link_128_[14],
	'hs_link_128_15' => $hs_link_128_[15],
	'hs_link_128_16' => $hs_link_128_[16],
	'hs_link_128_17' => $hs_link_128_[17],
	'hs_link_128_18' => $hs_link_128_[18],
	'hs_link_128_19' => $hs_link_128_[19],
	'hs_link_128_20' => $hs_link_128_[20],
	'hs_link_128_21' => $hs_link_128_[21],
	'hs_link_128_22' => $hs_link_128_[22],
	'hs_link_128_23' => $hs_link_128_[23],
	'hs_link_128_24' => $hs_link_128_[24],
	'hs_link_128_25' => $hs_link_128_[25],
	'hs_link_128_26' => $hs_link_128_[26],
	'hs_link_128_27' => $hs_link_128_[27],
	'hs_link_128_28' => $hs_link_128_[28],
	'hs_link_128_29' => $hs_link_128_[29],
	'hs_link_128_30' => $hs_link_128_[30],
	'hs_link_320_1' => $hs_link_320_[1],
	'hs_link_320_2' => $hs_link_320_[2],
	'hs_link_320_3' => $hs_link_320_[3],
	'hs_link_320_4' => $hs_link_320_[4],
	'hs_link_320_5' => $hs_link_320_[5],
	'hs_link_320_6' => $hs_link_320_[6],
	'hs_link_320_7' => $hs_link_320_[7],
	'hs_link_320_8' => $hs_link_320_[8],
	'hs_link_320_9' => $hs_link_320_[9],
	'hs_link_320_10' => $hs_link_320_[10],
	'hs_link_320_11' => $hs_link_320_[11],
	'hs_link_320_12' => $hs_link_320_[12],
	'hs_link_320_13' => $hs_link_320_[13],
	'hs_link_320_14' => $hs_link_320_[14],
	'hs_link_320_15' => $hs_link_320_[15],
	'hs_link_320_16' => $hs_link_320_[16],
	'hs_link_320_17' => $hs_link_320_[17],
	'hs_link_320_18' => $hs_link_320_[18],
	'hs_link_320_19' => $hs_link_320_[19],
	'hs_link_320_20' => $hs_link_320_[20],
	'hs_link_320_21' => $hs_link_320_[21],
	'hs_link_320_22' => $hs_link_320_[22],
	'hs_link_320_23' => $hs_link_320_[23],
	'hs_link_320_24' => $hs_link_320_[24],
	'hs_link_320_25' => $hs_link_320_[25],
	'hs_link_320_26' => $hs_link_320_[26],
	'hs_link_320_27' => $hs_link_320_[27],
	'hs_link_320_28' => $hs_link_320_[28],
	'hs_link_320_29' => $hs_link_320_[29],
	'hs_link_320_30' => $hs_link_320_[30],
	'hs_trackname_1' => $hs_trackname_[1],
	'hs_trackname_2' => $hs_trackname_[2],
	'hs_trackname_3' => $hs_trackname_[3],
	'hs_trackname_4' => $hs_trackname_[4],
	'hs_trackname_5' => $hs_trackname_[5],
	'hs_trackname_6' => $hs_trackname_[6],
	'hs_trackname_7' => $hs_trackname_[7],
	'hs_trackname_8' => $hs_trackname_[8],
	'hs_trackname_9' => $hs_trackname_[9],
	'hs_trackname_10' => $hs_trackname_[10],
	'hs_trackname_11' => $hs_trackname_[11],
	'hs_trackname_12' => $hs_trackname_[12],
	'hs_trackname_13' => $hs_trackname_[13],
	'hs_trackname_14' => $hs_trackname_[14],
	'hs_trackname_15' => $hs_trackname_[15],
	'hs_trackname_16' => $hs_trackname_[16],
	'hs_trackname_17' => $hs_trackname_[17],
	'hs_trackname_18' => $hs_trackname_[18],
	'hs_trackname_19' => $hs_trackname_[19],
	'hs_trackname_20' => $hs_trackname_[20],
	'hs_trackname_21' => $hs_trackname_[21],
	'hs_trackname_22' => $hs_trackname_[22],
	'hs_trackname_23' => $hs_trackname_[23],
	'hs_trackname_24' => $hs_trackname_[24],
	'hs_trackname_25' => $hs_trackname_[25],
	'hs_trackname_26' => $hs_trackname_[26],
	'hs_trackname_27' => $hs_trackname_[27],
	'hs_trackname_28' => $hs_trackname_[28],
	'hs_trackname_29' => $hs_trackname_[29],
	'hs_trackname_30' => $hs_trackname_[30],
	'dir_files' => $dir_files,
	'artist_en' => $artist_en,
	'song_en' => $song_en,
	'cover' => $cover_file_mp3
	);
	curl_setopt($ch, CURLOPT_POST,1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $wintheme);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_exec($ch); 

	$parent_post_id = $post_id;
	$filetype = wp_check_filetype( basename( $filename ), null );
	$wp_upload_dir = wp_upload_dir();
	$attachment = array(
		'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ), 
		'post_mime_type' => $filetype['type'],
		'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
		'post_content'   => '',
		'post_status'    => 'inherit'
	);
	$attach_id = wp_insert_attachment( $attachment, $filename, $parent_post_id );
	require_once( $_SERVER['DOCUMENT_ROOT'].'/wp-admin/includes/image.php' );
	$attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
	wp_update_attachment_metadata( $attach_id, $attach_data );
	set_post_thumbnail( $parent_post_id, $attach_id );
	function image_resize_win($filename, $width, $height) {
		$src = imagecreatefromjpeg($filename);
		list($w, $h) = getimagesize($filename);
		$img = imagecreatetruecolor($width, $height);
		imagecopyresampled($img, $src, 0, 0, 0, 0, $width, $height, $w, $h);
		imagejpeg($img, $filename, 50);
	}
	image_resize_win($filename, IMG_WIDTH, IMG_HEIGHT); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Advanced Post Maker</title>
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<body>
<center>
	<div class="entry">
		<div class="cadr">
			<textarea class="textarea" readonly="readonly" onclick="javascript:this.select();" name="comment" id="comment" style="float: right;width: 99%;height: 40px;text-align: center;">پست با موفقیت منتشر شد</textarea>
			<br>
			<a id="button" title="بازگشت" href="../index.php" style="display: inline-block;width: 450px;padding: 1em;">بازگشت</a>
		</div>
	</div>
</center>
</body>
</html>
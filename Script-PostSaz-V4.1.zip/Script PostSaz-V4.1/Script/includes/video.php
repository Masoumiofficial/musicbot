<?php
define('IMG_WIDTH',  480);
define('IMG_HEIGHT', 480);
require_once 'jdf.php';
include("../config.php");
include $_SERVER['DOCUMENT_ROOT'].'/wp-config.php';
set_time_limit(0);
$dir = jdate_win('Y/m/d', time());
$dir_file = "video/{$dir}";

$artist = $_POST['artist'];
$song = $_POST['track'];
$artist_en = $_POST['artist_en'];
$song_en = $_POST['track_en'];
$lyric = $_POST['lyric'];
$info = $_POST['info'];
$cover = $_POST['cover'];
$post_status = $_POST['post_status'];
$src = trim($cover);
$hs_video1080p = $_POST['hs_video1080p'];
$hs_video720p = $_POST['hs_video720p'];
$hs_video480p = $_POST['hs_video480p'];

$year = date("Y");
$months = date("m");

/* 
	Start Base
 */
$title = "دانلود موزیک ویدیو {$artist} {$song}";
$hs_postname = "download-new-music-video-{$artist} {$song}";
$cover_file = "video-{$artist_en}-{$song_en}";
$video_h2 = "ویدیو {$artist} {$song}";
$video_file = "{$artist_en} - {$song_en}";
/* 
	End Base 
*/

$artist_dashes = sanitize_title_with_dashes($artist);
$song_dashes = sanitize_title_with_dashes($song);
$artist_en_dashes = sanitize_title_with_dashes($artist_en);
$song_en_dashes = sanitize_title_with_dashes($song_en);
$Artist_Name_FA_TAG = "https://{$urlsite}/tag/{$artist_dashes}/";
$Song_Name_FA_TAG = "https://{$urlsite}/tag/{$song_dashes}/";
$Artist_Name_EN_TAG = "https://{$urlsite}/tag/{$artist_en_dashes}/";
$Song_Name_EN_TAG = "https://{$urlsite}/tag/{$song_en_dashes}/";

$hs_Cover = "https://{$urlsite}/wp-content/uploads/{$year}/{$months}/{$cover_file}.jpg";

$metadesc_text_fa = "دانلود موزیک ویدئو {$artist} {$song},دانلود موزیک ویدیو {$song} از {$artist} , Music Video {$artist_en} {$song_en}";

$my_post_content = "
<h2 style=\"text-align: center;\"><span style=\"color: #808080;\">موزیک ویدیو {$artist} {$song}</span></h2>
<p style=\"text-align: center;\"><strong><span style=\"color: #999999;\"><a href=\"https://mahyarmusic.com/category/musicvideo/\">دانلود موزیک ویدیو</a>  <a href=\"{$Artist_Name_FA_TAG}\">{$artist}</a> به نام <a href=\"{$Song_Name_FA_TAG}\">{$song}</a> با کیفیت عالی </span></strong></p>
<p style=\"text-align: center;\"><strong>{$artist_en} - {$song_en}</strong></p>
<p style=\"text-align: center;\">{$info}</p>
<p style=\"text-align: center;\"><img src=\"{$hs_Cover}\" alt=\"{$title}\" width=\"480\" height=\"480\" /></p>
<!--more-->
";

if($post_status == "publish") {
	$type_status = "publish";	
}
if($post_status == "draft") {
	$type_status = "draft";
}
$post_id = wp_insert_post( array(
	 'post_author' => '1',
	 'post_status' => $type_status,
	 'post_type' => 'post',
	 'post_title' => $title,
	 'post_name' => sanitize_title_with_dashes($video_h2),
	 'post_content' => $my_post_content,
 ) );

$arrayoftags = array(
	"$song",
	"$song_en",
	"$artist",
	"$artist_en",
	"دانلود موزیک ویدئو جدید"
);

	update_post_meta($post_id, '_yoast_wpseo_title', strip_tags($title));
	update_post_meta($post_id, '_yoast_wpseo_metadesc', strip_tags($metadesc_text_fa));
	update_post_meta($post_id, '_yoast_wpseo_focuskw', strip_tags($video_h2));
	update_post_meta($post_id, '_yoast_wpseo_linkdex', '99');
	update_post_meta($post_id, '_yoast_wpseo_content_score', '99');
 
	$filename1080p = "{$urldlhost}/{$dir_file}/{$video_file} (1080p).mp4";
	$filename720p = "{$urldlhost}/{$dir_file}/{$video_file} (720p).mp4";
	$filename480p = "{$urldlhost}/{$dir_file}/{$video_file} (480p).mp4";

	
	wp_set_object_terms($post_id, $artist, 'singer');
	wp_set_object_terms($post_id, $arrayoftags, 'post_tag');
	wp_set_object_terms($post_id, 'musicvideo', 'category');
	//update_post_meta($post_id, 'musics_type', 'mp4');
	update_post_meta($post_id, 'posttype', 'ویدیو');
 
 	if (!empty($artist)) update_post_meta($post_id, 'artist', $artist);
 	if (!empty($song)) update_post_meta($post_id, 'song', $song);
 	if (!empty($lyric)) update_post_meta($post_id, 'lyric_text', $lyric);
	

 	if (!empty($hs_video1080p)) update_post_meta($post_id, 'link_1080p', $filename1080p);
	if (!empty($hs_video720p)) update_post_meta($post_id, 'link_720p', $filename720p);
	if (!empty($hs_video480p)) update_post_meta($post_id, 'link_480p', $filename480p);
	if (!empty($hs_video480p)) update_post_meta($post_id, 'video_vonline', $filename480p);


	function Download($url, $saveto) {
		$content = file_get_contents($url);
		file_put_contents($saveto, $content);
	} 

if(isset($_FILES['mp3_image'])){
$target = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/{$year}/{$months}/{$cover_file}.jpg";
if(move_uploaded_file($_FILES['mp3_image']['tmp_name'],$target)) echo "";
} elseif ($_POST['cover']) {
	$target = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/{$year}/{$months}/{$cover_file}.jpg";
	Download($src,$target);
}
$filename = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/{$year}/{$months}/{$cover_file}.jpg";

$ch = curl_init($wintheme_url_function_video);
$wintheme = array(
'hs_video1080p' => $hs_video1080p,
'hs_video720p' => $hs_video720p,
'hs_video480p' => $hs_video480p,
'dir_file' => $dir_file,
'video_file' => $video_file
);
curl_setopt($ch, CURLOPT_POST,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $wintheme);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch); 


$parent_post_id = $post_id;
$filetype = wp_check_filetype( basename( $filename ), null );
$wp_upload_dir = wp_upload_dir();
$attachment = array(
	'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ), 
	'post_mime_type' => $filetype['type'],
	'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
	'post_content'   => '',
	'post_status'    => 'inherit'
);
$attach_id = wp_insert_attachment( $attachment, $filename, $parent_post_id );
require_once( $_SERVER['DOCUMENT_ROOT'].'/wp-admin/includes/image.php' );
$attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
wp_update_attachment_metadata( $attach_id, $attach_data );
set_post_thumbnail( $parent_post_id, $attach_id );
function image_resize_win($filename, $width, $height)
{
    $src = imagecreatefromjpeg($filename);
    list($w, $h) = getimagesize($filename);

    $img = imagecreatetruecolor($width, $height);
    imagecopyresampled($img, $src, 0, 0, 0, 0, $width, $height, $w, $h);
    imagejpeg($img, $filename, 50);
}
image_resize_win($filename, IMG_WIDTH, IMG_HEIGHT); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Advanced Post Maker</title>
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<body>
<center>
<div class="entry">
<div class="cadr">
<textarea class="textarea" readonly="readonly" onclick="javascript:this.select();" name="comment" id="comment" style="float: right;width: 99%;height: 40px;text-align: center;">پست با موفقیت در وبسایت منتشر شد</textarea>
<br>
<a id="button" title="بازگشت" href="../index.php" style="display: inline-block;width: 450px;padding: 1em;">بازگشت</a>
</div>
</div></center>
</body>
</html>

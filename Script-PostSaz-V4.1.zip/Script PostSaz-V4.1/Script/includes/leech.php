<?php
include("../config.php");
require_once 'jdf.php';
set_time_limit(0);
$dir = jdate_win('Y/m/d', time());
$dir_file = "{$dir}";
$enname = $_POST['enname'];
$entrack = $_POST['entrack'];
$cover = $_POST['cover'];
$src = trim($cover);
$linkfilemp3 = $_POST['linkfilemp3'];
$linkfilemp4 = $_POST['linkfilemp4'];
$mp3_name = "{$enname} - {$entrack}";


function Download($url, $saveto) {
    $content = file_get_contents($url);
    file_put_contents($saveto, $content);
}

 if (!empty($cover)) {
	$hs_src = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/temp.jpg";
	Download($src,$hs_src); 
	$hs_cover = "https://{$urlsite}/wp-content/uploads/temp.jpg";
	$urlnewfilejpg = "{$urldlhost}/{$dir_file}/{$mp3_name}.jpg";
} elseif ($_FILES['filecover']) {
	$hs_src = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/temp.jpg";
	if(move_uploaded_file($_FILES['filecover']['tmp_name'],$hs_src));
	$hs_cover = "https://{$urlsite}/wp-content/uploads/temp.jpg";
	$urlnewfilejpg = "{$urldlhost}/{$dir_file}/{$mp3_name}.jpg";
 }
 
 if (!empty($linkfilemp3)) {
	$hs_musics = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/temp_music.mp3";
	Download($linkfilemp3,$hs_musics); 
	$hs_music = "https://{$urlsite}/wp-content/uploads/temp_music.mp3";
	$urlnewfileMp3 = "{$urldlhost}/{$dir_file}/{$mp3_name}.mp3";
} elseif ($_FILES['filemusic']) {
	$hs_musics = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/temp_music.mp3";
	if(move_uploaded_file($_FILES['filemusic']['tmp_name'],$hs_musics));
	$hs_music = "https://{$urlsite}/wp-content/uploads/temp_music.mp3";
	$urlnewfileMp3 = "{$urldlhost}/{$dir_file}/{$mp3_name}.mp3";
 }

 if (!empty($linkfilemp3)) {
	$hs_videos = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/temp_video.mp4";
	Download($linkfilemp4,$hs_videos); 
	$hs_video = "https://{$urlsite}/wp-content/uploads/temp_video.mp4";
	$urlnewfileMp4 = "{$urldlhost}/{$dir_file}/{$mp3_name}.mp4";
} elseif ($_FILES['filevideo']) {
	$hs_videos = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/temp_video.mp4";
	if(move_uploaded_file($_FILES['filevideo']['tmp_name'],$hs_videos));
	$hs_video = "https://{$urlsite}/wp-content/uploads/temp_video.mp4";
	$urlnewfileMp4 = "{$urldlhost}/{$dir_file}/{$mp3_name}.mp4";
 }


$ch = curl_init($wintheme_url_function_leech);
$data = array(
'linkfilemp3' => $hs_music,
'enname' => $enname,
'entrack' => $entrack,
'cover' => $hs_cover,
'dir_file' => $dir_file,
'mp3_name' => $mp3_name,
'linkfilemp4' => $hs_video
);
curl_setopt($ch, CURLOPT_POST,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch); 

	
unlink($hs_src);
unlink($hs_musics);
unlink($hs_videos);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>پست سریع موزیک وین تم</title>
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<body>
<center>
<div class="entry">
<div class="cadr">
<?php if($urlnewfilejpg){?>
<textarea class="textarea" readonly="readonly" onclick="javascript:this.select();" name="comment" id="comment" style="float: right;width: 99%;height: 30px;text-align: center;padding: 5px;"><?php echo $urlnewfilejpg;?></textarea>
<?php } if($urlnewfileMp3){?>
<textarea class="textarea" readonly="readonly" onclick="javascript:this.select();" name="comment" id="comment" style="float: right;width: 99%;height: 30px;text-align: center;padding: 5px;"><?php echo $urlnewfileMp3;?></textarea>
<?php } if($urlnewfileMp4){?>
<textarea class="textarea" readonly="readonly" onclick="javascript:this.select();" name="comment" id="comment" style="float: right;width: 99%;height: 30px;text-align: center;padding: 5px;"><?php echo $urlnewfileMp4;?></textarea>
<?php }?>

<br>
<a id="button" title="بازگشت" href="../index.php" style="display: inline-block;width: 450px;padding: 1em;">بازگشت</a>
</div>
</div></center>
</body>
</html>


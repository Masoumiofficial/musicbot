<?php
define('IMG_WIDTH',  480);
define('IMG_HEIGHT', 480);
require_once 'jdf.php';
include("../config.php");
include $_SERVER['DOCUMENT_ROOT'].'/wp-config.php';
set_time_limit(0);
$dir = jdate_win('Y/m/d', time());
$artist = $_POST['artist'];$song = $_POST['track'];$artist_en = $_POST['artist_en'];$song_en = $_POST['track_en'];$info = $_POST['info'];$lyric = $_POST['lyric'];$lyric2 = $_POST['lyric2'];$musictype = $_POST['musictype'];$fatxt = $_POST['fatxt'];$entxt = $_POST['entxt'];$imgtxt = $_POST['imgtxt'];$txtseo = $_POST['ttlfa'];$is_draft = $_POST['is_draft'];$covermp3 = $_POST['covermp3'];$cover = $_POST['cover'];$music320 = $_POST['music320'];$music128 = $_POST['music128'];
$year = date("Y");
$months = date("m");
$src = trim($cover);



if($musictype == "music") { 
	$win_musictype = "آهنگ";
	$win_musictype_en = "Music";
	$win_musictype_h2 = "{$artist} {$song}";
	$win_musictype_category = "music";
	$title = "دانلود آهنگ {$artist} {$song}";
	$mp3_file = "{$artist_en} - {$song_en}";
	$cover_file = "{$artist_en} - {$song_en}";
	$dir_file = "music/{$dir}";

}
if($musictype == "remix") {
	$win_musictype = "ریمیکس ";
	$win_musictype_en = "Remix";
	$win_musictype_h2 = "ریمیکس {$artist} {$song}";
	$win_musictype_category = "remix";
	$title = "دانلود ریمیکس آهنگ {$artist} {$song}";
	$mp3_file = "{$artist_en} - {$song_en} (Remix)";
	$cover_file = "{$artist_en} - {$song_en} (Remix)";
	$dir_file = "remix/{$dir}";
}
if($musictype == "nohe") { 
	$win_musictype = "مداحی";
	$win_musictype_en = "Madahi";
	$win_musictype_h2 = "مداحی {$song}";
	$win_musictype_category = "madahi";
	$title = "دانلود مداحی {$artist} {$song}";
	$mp3_file = "{$artist_en} - {$song_en}";
	$cover_file = "{$artist_en} - {$song_en}";
	$dir_file = "nohe/{$dir}";
}
if($musictype == "pod") { 
	$win_musictype = "پادکست";
	$win_musictype_en = "Podcast";
	$win_musictype_h2 = "{$artist} {$song}";
	$win_musictype_category = "podcast";
	$title = "دانلود پادکست {$artist} {$song}";
	$mp3_file = "{$artist_en} - {$song_en}";
	$cover_file = "{$artist_en} - {$song_en}";
	$dir_file = "podcast/{$dir}";

}

$art_dashes = sanitize_title_with_dashes($artist);
$song_dashes = sanitize_title_with_dashes($song);
$art_en_dashes = sanitize_title_with_dashes($artist_en);
$song_en_dashes = sanitize_title_with_dashes($song_en);

$Artist_Name_FA_TAG = "https://{$urlsite}/tag/{$art_dashes}/";
$Song_Name_FA_TAG = "https://{$urlsite}/tag/{$song_dashes}/";
$Artist_Name_EN_TAG = "https://{$urlsite}/tag/{$art_en_dashes}/";
$Song_Name_EN_TAG = "https://{$urlsite}/tag/{$song_en_dashes}/";

$IMG_POST = "https://{$urlsite}/wp-content/uploads/{$year}/{$months}/{$cover_file}.jpg";

if(!empty($_POST['info'])) {
	$content_info = "<p style=\"text-align: center;\">{$info}</p>";
}


/* Music Single */

if($musictype == "music") { 

$my_post_content = "
<h2 style=\"text-align: center;\"><span style=\"color: #808080;\">{$artist} {$song}</span></h2>
<p style=\"text-align: center;\"><strong><span style=\"color: #999999;\"><a href=\"https://musiceet.ir/category/music/\">دانلود آهنگ جدید</a>  <a href=\"{$Artist_Name_FA_TAG}\">{$artist}</a> به نام <a href=\"{$Song_Name_FA_TAG}\">{$song}</a> با دو کیفیت عالی + متن آهنگ</span></strong></p>
<p style=\"text-align: center;\"><strong>{$artist_en} - {$song_en}</strong></p>
{$lg_info}
<p style=\"text-align: center;\"><img src=\"{$IMG_POST}\" alt=\"{$title}\" width=\"480\" height=\"480\" /></p>
<!--more-->
";

$arrayoftags = array(
	"دانلود آهنگ جدید",
	"$song",
	"$artist"
);

$metadesc_text_fa = "دانلود آهنگ {$song} از {$artist} , دانلود آهنگ جدید {$artist} به نام {$song} با کیفیت ۱۲۸ و ۳۲۰";
$title_seo = "";
}

/* End Music Single */
/* Start Remix */

if($musictype == "remix") {

$my_post_content = "
<h2 style=\"text-align: center;\"><span style=\"color: #808080;\">ریمیکس {$artist} {$song}</span></h2>
<p style=\"text-align: center;\"><strong><span style=\"color: #999999;\"><a href=\"https://musiceet.ir/category/remix/\">دانلود ریمیکس جدید</a>  <a href=\"{$Artist_Name_FA_TAG}\">{$artist}</a> به نام <a href=\"{$Song_Name_FA_TAG}\">{$song}</a> با دو کیفیت عالی + متن آهنگ</span></strong></p>
<p style=\"text-align: center;\"><strong>{$artist_en} - {$song_en}</strong></p>
{$lg_info}
<p style=\"text-align: center;\"><img src=\"{$IMG_POST}\" alt=\"{$title}\" width=\"480\" height=\"480\" /></p>
<!--more-->
";

$arrayoftags = array(
	"$artist",
	"$song",
	"دانلود ریمیکس $song",
	"دانلود اهنگ جدید",
	"دانلود ریمیکس"
);

$metadesc_text_fa = "دانلود ریمیکس آهنگ {$song} از {$artist} , دانلود ریمیکس جدید {$artist} به نام {$song} با کیفیت ۱۲۸ و ۳۲۰";
$title_seo = "";
}

/* End Remix */
/* Start Nohe */

if($musictype == "nohe") { 

$my_post_content = "
<h2 style=\"text-align: center;\"><span style=\"color: #808080;\">مداحی {$artist} {$song}</span></h2>
<p style=\"text-align: center;\"><strong><span style=\"color: #999999;\"><a href=\"https://musiceet.ir/category/madahi/\">دانلود مداحی جدید</a>  <a href=\"{$Artist_Name_FA_TAG}\">{$artist}</a> به نام <a href=\"{$Song_Name_FA_TAG}\">{$song}</a> با دو کیفیت عالی + متن آهنگ</span></strong></p>
<p style=\"text-align: center;\"><strong>{$artist_en} - {$song_en}</strong></p>
{$lg_info}
<p style=\"text-align: center;\"><img src=\"{$IMG_POST}\" alt=\"{$title}\" width=\"480\" height=\"480\" /></p>
<!--more-->
";

$arrayoftags = array(
	"$artist",
	"$song",
	"دانلود مداحی",
	"نوحه"
);

$metadesc_text_fa = "دانلود مداحی {$song} از {$artist} , دانلود مداحی جدید {$artist} به نام {$song} با کیفیت ۱۲۸ و ۳۲۰";
$title_seo = "";
}
/* End Nohe */
/* Start Podcast */
if($musictype == "pod") { 

$my_post_content = "
<h2 style=\"text-align: center;\"><span style=\"color: #808080;\">پادکست {$artist} {$song}</span></h2>
<p style=\"text-align: center;\"><strong><span style=\"color: #999999;\"><a href=\"https://musiceet.ir/category/podcast/\">دانلود پادکست جدید</a>  <a href=\"{$Artist_Name_FA_TAG}\">{$artist}</a> به نام <a href=\"{$Song_Name_FA_TAG}\">{$song}</a> با دو کیفیت عالی + متن آهنگ</span></strong></p>
<p style=\"text-align: center;\"><strong>{$artist_en} - {$song_en}</strong></p>
{$lg_info}
<p style=\"text-align: center;\"><img src=\"{$IMG_POST}\" alt=\"{$title}\" width=\"480\" height=\"480\" /></p>
<!--more-->
";

$arrayoftags = array(
	"دانلود پادکست جدید",
	"$song",
	"$artist"
);

$metadesc_text_fa = "دانلود پادکست جدید {$song} از {$artist} , دانلود آهنگ جدید {$artist} به نام {$song} با کیفیت ۱۲۸ و ۳۲۰";
$title_seo = "";
}
/* end Podcast */

if($is_draft == "publish") {
	$type="publish";
	$type_status = " 🟢 پست با موفقیت منتشر شد";
}
if($is_draft == "draft") {
	$type="draft";
	$type_status = " 🟠 پست با موفقیت پیشنویس شد";
}

$post_id = wp_insert_post( array(
	 'post_author' => '1',
	 'post_status' => $type,
	 'post_type' => 'post',
	 'post_title' => $title,
	 'post_name' => sanitize_title_with_dashes($win_musictype_h2),
	 'post_content' => $my_post_content,
 ) );


	update_post_meta($post_id, '_yoast_wpseo_title', strip_tags($title_seo));
	update_post_meta($post_id, '_yoast_wpseo_metadesc', strip_tags($metadesc_text_fa));
	update_post_meta($post_id, '_yoast_wpseo_focuskw', strip_tags($win_musictype_h2));
	update_post_meta($post_id, '_yoast_wpseo_linkdex', '99');
	update_post_meta($post_id, '_yoast_wpseo_content_score', '99');
 
	$filename320 = "{$urldlhost}/{$dir_file}/{$mp3_file}.mp3";
	$filename128 = "{$urldlhost}/{$dir_file}/{$mp3_file} (128).mp3";
	
	wp_set_object_terms($post_id, $artist, 'singer');
	wp_set_object_terms($post_id, $arrayoftags, 'post_tag');
	wp_set_object_terms($post_id, $win_musictype_category, 'category');
	
	function Download($url, $saveto) {
		$content = file_get_contents($url);
		file_put_contents($saveto, $content);
	} 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

if (!empty($music320)) {
	  $link_320 = $music320;
	  if (!empty($music320)) update_post_meta($post_id, 'music320', $filename320);
	
} elseif ($_FILES['filemusic320']) {
		$target_320 = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/{$year}/{$months}/temp.mp3";
		if(move_uploaded_file($_FILES['filemusic320']['tmp_name'],$target_320));
		$link_320 = "http://{$urlsite}/wp-content/uploads/{$year}/{$months}/temp.mp3";
		if (!empty($_FILES['filemusic320']['tmp_name'])) update_post_meta($post_id, 'music320', $filename320);
} 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
 if (!empty($music128)) {
	 
	$link_128 = $music128;
	if (!empty($music128)) update_post_meta($post_id, 'music128', $filename128); 
	
} elseif ($_FILES['filemusic128']) {
	
	$target_128 = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/{$year}/{$months}/temp-128.mp3";
	if(move_uploaded_file($_FILES['filemusic128']['tmp_name'],$target_128));	
	$link_128 = "http://{$urlsite}/wp-content/uploads/{$year}/{$months}/temp-128.mp3";	
	if (!empty($_FILES['filemusic128']['tmp_name'])) update_post_meta($post_id, 'music128', $filename128);
	
} 


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 

	
 if (!empty($cover)) {

$target_cover = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/{$year}/{$months}/{$cover_file}.jpg";
Download($src,$target_cover);

} elseif ($_FILES['mp3_image']) {

$target_img = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/{$year}/{$months}/{$cover_file}.jpg";
if(move_uploaded_file($_FILES['mp3_image']['tmp_name'],$target_img));
		
} 

if (!empty($covermp3)){
	$hs_coverfile = str_replace(" ", "%20", $covermp3); 
} else {
	$hs_coverfile = str_replace(" ", "%20", $IMG_POST); 
}
	
	update_post_meta($post_id, 'posttype', $types);
	if (!empty($artist)) update_post_meta($post_id, 'artist', $artist);
	if (!empty($song)) update_post_meta($post_id, 'song', $song);
	if (!empty($lyric)) update_post_meta($post_id, 'lyric_text', $lyric);

$ch = curl_init($wintheme_url_function_dl);
$wintheme = array(
	'link128' => $link_128,
	'link320' => $link_320,
	'mp3_file' => $mp3_file,
	'dir_file' => $dir_file,
	'artist_en' => $artist_en,
	'song_en' => $song_en,
	'cover' => $hs_coverfile
);
curl_setopt($ch, CURLOPT_POST,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $wintheme);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch); 

$filename = $_SERVER['DOCUMENT_ROOT']."/wp-content/uploads/{$year}/{$months}/{$cover_file}.jpg";
$parent_post_id = $post_id;
$filetype = wp_check_filetype( basename( $filename ), null );
$wp_upload_dir = wp_upload_dir();
$attachment = array(
	'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ), 
	'post_mime_type' => $filetype['type'],
	'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
	'post_content'   => '',
	'post_status'    => 'inherit'
);
$attach_id = wp_insert_attachment( $attachment, $filename, $parent_post_id );
require_once( $_SERVER['DOCUMENT_ROOT'].'/wp-admin/includes/image.php' );
$attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
wp_update_attachment_metadata( $attach_id, $attach_data );
set_post_thumbnail( $parent_post_id, $attach_id );
function image_resize_win($filename, $width, $height)
{
    $src = imagecreatefromjpeg($filename);
    list($w, $h) = getimagesize($filename);

    $img = imagecreatetruecolor($width, $height);
    imagecopyresampled($img, $src, 0, 0, 0, 0, $width, $height, $w, $h);
    imagejpeg($img, $filename, 50);
}
image_resize_win($filename, IMG_WIDTH, IMG_HEIGHT); 
unlink($target_320);
unlink($target_128);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Advanced Post Maker</title>
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<body>
<center>
<div class="entry">
<div class="cadr">
<textarea class="textarea" readonly="readonly" onclick="javascript:this.select();" name="comment" id="comment" style="float: right;width: 99%;height: 40px;text-align: center;"><?php echo $type_status;?></textarea>
<br>
<a id="button" title="بازگشت" href="../index.php" style="display: inline-block;width: 450px;padding: 1em;">بازگشت</a>
</div>
</div></center>
</body>
</html>
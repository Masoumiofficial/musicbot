<!DOCTYPE html>
<html dir="rtl" lang="fa-IR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Advanced Post Maker</title>
<META NAME="robots" CONTENT="noindex, nofollow">
<link href="style.css" rel="stylesheet" type="text/css">
<script src="js/jquery.js"></script>
<script>  
jQuery(document).ready(function($) {
    $("input[type=file]").change(function () {
        $(this).parents(".uploader").find(".filename").val($(this).val());
    });
    $("input[type=file]").each(function () {
        if ($(this).val() == "") {
            $(this).parents(".uploader").find(".filename").val("هنوز فایلی انتخاب نشده...");
        }
    });
    });
jQuery(document).ready(function() {
    jQuery(".func_panel .morebtn span").click(function() {
        jQuery(this).parent().parent().css("height","100%");
        jQuery(this).parent().remove();
    });
    jQuery(".tabs .items").click(function(event) {
        event.preventDefault();
        jQuery(this).addClass("active");
        jQuery(this).siblings().removeClass("active");
        var tab = jQuery(this).attr("href");
        jQuery(".tabcontent").not(tab).css("display", "none");
        jQuery(tab).fadeIn();
    });
});
</script>
</head>
<body>
<div class="newtab">
<!-- The navigation menu -->
<div class="navbar">
  <a href="#home">صفحه اصلی سایت</a>
  <div class="subnav">
    <button class="subnavbtn">دسته ها <i class="cat-icon"></i></button>
    <div class="subnav-content">
	<?php include ('menu.php'); ?>
    </div>
  </div>
  <a href="https://wintheme.ir">پشتیبانی</a>
</div> 
</div>
<center><div class="entry">
<div class="cadr">
<form enctype='multipart/form-data' method="POST" action="includes/album.php">
<div class="title">
<label>وضعیت پست</label>
<select name="is_draft" id="is_draft" style="padding: 5px;">
<option value="publish">منتشر شود</option>
<option value="draft">پیشنویس شود</option>
</select>
</div>
<input type="text" name="artist" placeholder="نام خواننده" style="text-align:right;padding: 5px;" required>
<input type="text" name="track" placeholder="نام آلبوم" style="text-align:right;padding: 5px;">
<input type="text" name="artist_en" placeholder="نام خواننده - انگلیسی" style="direction: ltr;text-align:right;padding: 5px;" required>
<input type="text" name="track_en" placeholder="نام آلبوم - انگلیسی" style="direction: ltr;text-align:right;padding: 5px;">
<input type="text" name="info" placeholder="اطلاعات پست" style="width: 98%;text-align:right;padding: 5px;">
<input type="text" name="covermp3" placeholder="کاور فایل MP3" style="width: 98%;text-align:right;padding: 5px;">
<?php
echo '<div class="func_panel" style="height:215px;overflow: hidden;"><table style="width:98%;"><thead> <tr> <th> # </th> <th> نام فارسی ترک </th> <th> نام انگلیسی ترک </th> <th> لینک 320 </th> <th> لینک 128 </th></tr> </thead><tbody>';
	for($i=1;$i<=30;$i++) {
		echo '<tr>';
		echo '<td style="text-align:center;"> '.$i.' </td>';
		echo '<td> <input type="text" name="trackfa_'.$i.'_name" style="width:98%;text-align:right;padding: 5px;" placeholder="نام فارسی" > </td>';
		echo '<td> <input type="text" name="tracken_'.$i.'_name" style="width:98%;text-align:right;padding: 5px;" dir="ltr" placeholder="نام انگلیسی"> </td>';
		echo '<td> <input type="url" name="track_'.$i.'_320" style="width:98%;text-align:right;padding: 5px;" dir="ltr" placeholder="لینک 320"> </td>';
		echo '<td> <input type="url" name="track_'.$i.'_128" style="width:98%;text-align:right;padding: 5px;" dir="ltr" placeholder="لینک 128"> </td>';
		echo '</tr>';
	}
	echo '</tbody></table>';
	echo '<div class="morebtn"> <span> نمایش بیشتر ... </span> </div></div>';
?>
<br>
<div class="uploader" style="width: 36%;">
<input name="mp3_image" type="file">
<input name="file" class="button" value="فایل تصویر شاخص" type="button">
<input class="filename" readonly="readonly" type="text">
</div>
<input type="text" name="cover" placeholder="لینک کاور پست" style="width: 60%;text-align:right;padding: 5px;border: 1px solid #b3000c;border-radius: 1em;">
<br>
<input type="submit" name="button" id="button" class="backk" value="ارسال پست">
</form>
</div>
</div>
</body>
</html>
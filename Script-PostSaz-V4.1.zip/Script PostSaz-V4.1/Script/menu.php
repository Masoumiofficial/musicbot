<?php 
$site = "http://musiceet.ir";
$bots = "postsaz";
?>
<a href="<?=$site; ?>/<?=$bots; ?>/index.php"><i class="icon-music"></i> تک آهنگ </a>
<a href="<?=$site; ?>/<?=$bots; ?>/video.php"><i class="icon-video"></i> موزیک ویدیو </a>
<a href="<?=$site; ?>/<?=$bots; ?>/album.php"><i class="icon-folder-open"></i> آلبوم</a>
<a href="<?=$site; ?>/<?=$bots; ?>/leech.php"><i class="icon-cloud-upload-alt"></i> آپلود و تغییر تگ موزیک</a>
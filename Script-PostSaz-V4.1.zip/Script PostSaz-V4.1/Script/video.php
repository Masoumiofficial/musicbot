<!DOCTYPE html><html dir="rtl" lang="fa-IR">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Advanced Post Maker</title>
<META NAME="robots" CONTENT="noindex, nofollow">
<link href="style.css" rel="stylesheet" type="text/css">
<script src="js/jquery.js"></script>
</head>
<body>
<div class="newtab">
<!-- The navigation menu -->
<div class="navbar">
  <a href="#home">صفحه اصلی سایت</a>
  <div class="subnav">
    <button class="subnavbtn">دسته ها <i class="cat-icon"></i></button>
    <div class="subnav-content">
	<?php include ('menu.php'); ?>
    </div>
  </div>
  <a href="https://wintheme.ir">پشتیبانی</a>
</div> 
</div>
<center>
<div class="entry">
<div class="cadr">
<form enctype='multipart/form-data' method="POST" action="includes/video.php">
<script>  
jQuery(document).ready(function($) {
    $("input[type=file]").change(function () {
        $(this).parents(".uploader").find(".filename").val($(this).val());
    });
    $("input[type=file]").each(function () {
        if ($(this).val() == "") {
            $(this).parents(".uploader").find(".filename").val("هنوز فایلی انتخاب نشده...");
        }
    });
    });
</script>

<div class="title">
<label>وضعیت پست</label>
<select name="post_status" style="padding: 5px;">
<option value="draft">پیشنویس شود</option>
<option value="publish">منتشر شود</option>
</select>
</div>
<input type="text" name="artist" placeholder="نام خواننده - فارسی" style="text-align:right;padding: 5px;" required>
<input type="text" name="track" placeholder="نام اثر - فارسی" style="text-align:right;padding: 5px;" required>
<input type="text" name="artist_en" placeholder="نام خواننده - انگلیسی" style="direction: ltr;text-align:left;padding: 5px;" required>
<input type="text" name="track_en" placeholder="نام اثر - انگلیسی" style="direction: ltr;text-align:left;padding: 5px;" required>
<input type="text" name="info" placeholder="اطلاعات پست" style="width: 98%;text-align:right;padding: 5px;">
<textarea name="lyric" placeholder="متن آهنگ" style="width: 98%; resize: vertical;height: 10em;text-align: center;"></textarea>
<input type="text" name="hs_video1080p" placeholder="لینک موزیک ویدیو - کیفیت 1080p" style="width: 98%;text-align:right;padding: 5px;">
<input type="text" name="hs_video720p" placeholder="لینک موزیک ویدیو - کیفیت 720p" style="width: 98%;text-align:right;padding: 5px;">
<input type="text" name="hs_video480p" placeholder="لینک موزیک ویدیو - کیفیت 480p" style="width: 98%;text-align:right;padding: 5px;">
<div class="uploader" style="width: 36%;">
<input name="mp3_image" type="file">
<input name="file" class="button" value="فایل تصویر شاخص" type="button">
<input class="filename" readonly="readonly" type="text">
</div>
<input type="text" name="cover" placeholder="لینک کاور پست" style="width: 60%;text-align:right;padding: 5px;border: 1px solid #b3000c;border-radius: 1em;">
<br>
<input type="submit" name="button" id="button" class="backk" value="ارسال پست">
</form>
</div>
</div>
</body>
</html>
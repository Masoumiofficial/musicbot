<?php
//******************************************
// @ This Script created by Saeid Moradi
// @ Email: saeid.m2126@gmail.com
// @ URL  : http://wintheme.ir
//******************************************
//
//
//
$urldlhost = 'https://dl1.musiceet.ir';
//
$wintheme_url_function_dl = 'https://dl1.musiceet.ir/curl-music.php';
$wintheme_url_function_video = 'https://dl1.musiceet.ir/curl-video.php';
$wintheme_url_function_album = 'https://dl1.musiceet.ir/curl-album.php';
$wintheme_url_function_leech = 'https://dl1.musiceet.ir/curl-leech.php';
//
//
$urlsite = "musiceet.ir"; 
//
//
//
?>
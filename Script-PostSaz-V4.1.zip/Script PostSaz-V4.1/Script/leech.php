<!DOCTYPE html>
<html dir="rtl" lang="fa-IR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>پست سریع موزیک وین تم</title>
<META NAME="robots" CONTENT="noindex, nofollow">
<link href="style.css" rel="stylesheet" type="text/css">
<script src="js/jquery.js"></script>
</head>
<body>
<div class="newtab">
<!-- The navigation menu -->
<div class="navbar">
  <a href="#home">صفحه اصلی سایت</a>
  <div class="subnav">
    <button class="subnavbtn">دسته ها <i class="cat-icon"></i></button>
    <div class="subnav-content">
	<?php include ('menu.php'); ?>
    </div>
  </div>
  <a href="https://wintheme.ir">پشتیبانی</a>
</div> 
</div>
<center>
<div class="entry">
<div class="cadr">
<form id="form" name="form" method="post" action="includes/leech.php">
<script>  
jQuery(document).ready(function($) {
    $("input[type=file]").change(function () {
        $(this).parents(".uploader").find(".filename").val($(this).val());
    });
    $("input[type=file]").each(function () {
        if ($(this).val() == "") {
            $(this).parents(".uploader").find(".filename").val("هنوز فایلی انتخاب نشده...");
        }
    });
    });
</script>
<input type="text" name="enname" placeholder="نام خواننده - انگلیسی" style="direction: ltr;text-align:left;padding: 5px;" required>
<input type="text" name="entrack" placeholder="نام اثر - انگلیسی" style="direction: ltr;text-align:left;padding: 5px;" required>

<div class="uploader" style="width: 36%;">
<input name="filecover" type="file">
<input name="file" class="button" value="فایل کاور MP3" type="button">
<input class="filename" readonly="readonly" type="text">
</div>
<input type="url" name="cover" placeholder="لینک کاور فایل MP3" style="width: 62%;text-align:right;padding: 5px;">

<div class="uploader" style="width: 36%;">
<input name="filemusic" type="file">
<input name="file" class="button" value="فایل موزیک" type="button">
<input class="filename" readonly="readonly" type="text">
</div>
<input type="url" name="linkfilemp3" placeholder="لینک MP3" style="width: 62%;text-align:right;padding: 5px;">

<div class="uploader" style="width: 36%;">
<input name="filevideo" type="file">
<input name="file" class="button" value="فایل ویدیو" type="button">
<input class="filename" readonly="readonly" type="text">
</div>
<input type="url" name="linkfilemp4" placeholder="لینک MP4" style="width: 62%;text-align:right;padding: 5px;">
<br>
<center>
<input type="submit" name="button" id="button" value="آپلود فایل">
</center>
</form>
</div>
</div>
</center>
</body>
</html>